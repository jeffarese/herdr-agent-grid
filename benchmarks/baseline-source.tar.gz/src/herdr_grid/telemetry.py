"""Read only a matched agent session; never attach a nearby unrelated log.

Provider transcripts are optional. Herdr remains the source of lifecycle state.
Initial reads are bounded to a tail plus a small header. Cumulative provider
totals remain exact; Claude totals reconstructed from a truncated tail are
explicitly marked partial. Estimated token costs are separate from reported cost.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime
import json
import math
import os
from pathlib import Path
import re
import time

from .model import Agent, clean
from .pricing import VERIFIED, estimate as price_estimate

MAX_READ = 2 * 1024 * 1024
SESSION_ID = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")


def timestamp(value) -> float | None:
    try:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            result = float(value)
            result = result / 1000 if result > 100_000_000_000 else result
        elif isinstance(value, str):
            result = datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
        else:
            return None
        return result if math.isfinite(result) and result > 0 else None
    except (ValueError, OverflowError, OSError):
        return None


def number(value) -> float | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0:
        return value
    return None


def one_line(value: str, limit: int = 160) -> str:
    return " ".join(clean(value).split())[:limit]


@dataclass(frozen=True)
class ToolCall:
    id: str
    name: str
    at: float | None = None
    done: bool = False
    error: bool = False


@dataclass
class Metrics:
    last_call: str = ""
    call_at: float | None = None
    call_done: bool | None = None
    call_detail: str = ""
    call_source: str = ""
    started_at: float | None = None
    seen_at: float = 0.0
    status_since: float = 0.0
    tokens: int | None = None
    tokens_partial: bool = False
    cost: float | None = None
    cost_partial: bool = False
    estimated_cost: float | None = None
    estimate_partial: bool = False
    estimate_note: str = ""
    model: str = ""
    effort: str = ""
    cost_reason: str = ""
    source: str = ""
    issue: str = ""
    phase: str = ""
    trail: tuple[ToolCall, ...] = ()
    last_message: str = ""
    message_at: float | None = None


@dataclass
class Cursor:
    path: Path
    offset: int = 0
    identity: tuple = ()
    boundary: bytes = b""
    metrics: Metrics = field(default_factory=Metrics)
    call_id: str = ""
    usages: dict = field(default_factory=dict)
    cumulative_tokens: bool = False
    truncated: bool = False
    estimates: dict = field(default_factory=dict)
    codex_totals: dict | None = None
    estimate_incomplete: bool = False


def update_estimate(cursor: Cursor) -> None:
    values = [cost for cost, _ in cursor.estimates.values() if cost is not None]
    m = cursor.metrics
    m.estimated_cost = sum(values) if values else None
    m.estimate_partial = cursor.truncated or cursor.estimate_incomplete or len(values) < len(cursor.estimates)
    notes = list(dict.fromkeys(note for _, note in cursor.estimates.values()))
    m.estimate_note = "; ".join(notes[:3]) + f" · rates {VERIFIED}"


def roots(provider: str) -> list[Path]:
    home = Path.home()
    if provider == "claude":
        values = [Path(os.environ.get("CLAUDE_CONFIG_DIR", str(home / ".claude"))),
                  *home.glob(".claude-*")]
        values += [Path(p) for p in os.environ.get("HERDR_GRID_CLAUDE_DIRS", "").split(os.pathsep) if p]
        return list(dict.fromkeys(p.expanduser().resolve() / "projects" for p in values))
    if provider == "codex":
        base = Path(os.environ.get("CODEX_HOME", str(home / ".codex"))).expanduser().resolve()
        return [base / "sessions", base / "archived_sessions"]
    return []


def tool_detail(value) -> str:
    """A descriptive label or file target, without dumping command arguments."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return ""
    if not isinstance(value, dict):
        return ""
    for key in ("description", "file_path", "path"):
        if isinstance(value.get(key), str):
            return one_line(value[key])
    return ""


def consume(cursor: Cursor, record: dict, provider: str) -> None:
    m = cursor.metrics
    at = timestamp(record.get("timestamp"))
    if at is not None and (m.started_at is None or at < m.started_at):
        m.started_at = at
    payload = record.get("payload")
    payload = payload if isinstance(payload, dict) else {}
    message = record.get("message")
    message = message if isinstance(message, dict) else {}
    kind = record.get("type")

    def call(name, call_id, detail=""):
        if isinstance(name, str) and name:
            cid = str(call_id or record.get("uuid") or f"{name}:{at}")
            previous = next((c for c in m.trail if c.id == cid), None)
            m.last_call = one_line(name, 80)
            m.call_at, m.call_done = (previous.at, previous.done) if previous else (at, False)
            m.call_source, m.call_detail = "transcript", detail
            cursor.call_id = cid
            m.phase = "tool"
            if previous is None:
                m.trail = (*m.trail[-23:], ToolCall(cid, m.last_call, at))

    def returned(call_id, error=False):
        m.trail = tuple(replace(c, done=True, error=bool(error)) if c.id == call_id else c for c in m.trail)
        if cursor.call_id and call_id == cursor.call_id:
            m.call_done = True
        if m.phase == "tool" and not any(not c.done for c in m.trail):
            m.phase = "working"

    def assistant_message(content):
        pieces = [b.get("text") for b in content if isinstance(b, dict) and
                  b.get("type") in ("text", "output_text") and isinstance(b.get("text"), str)]
        text = one_line(" ".join(pieces), 1200)
        if text:
            m.last_message, m.message_at = text, at

    if provider == "codex":
        if kind == "session_meta":
            m.started_at = timestamp(payload.get("timestamp")) or at or m.started_at
        elif kind == "turn_context":
            if isinstance(payload.get("model"), str):
                m.model = one_line(payload["model"], 80)
            for key in ("effort", "reasoning_effort", "model_reasoning_effort"):
                if key in payload:
                    m.effort = one_line(payload[key], 24) if isinstance(payload[key], str) else ""
                    break
        elif kind == "response_item":
            if payload.get("type") == "reasoning":
                m.phase = "thinking"
            elif payload.get("type") == "message" and payload.get("role") == "assistant":
                m.phase = "writing"
                if isinstance(payload.get("content"), list):
                    assistant_message(payload["content"])
            elif payload.get("type") in ("function_call", "custom_tool_call"):
                call(payload.get("name"), payload.get("call_id"),
                     tool_detail(payload.get("arguments", payload.get("input"))))
            elif payload.get("type") in ("function_call_output", "custom_tool_call_output"):
                returned(payload.get("call_id"))
        elif kind == "event_msg" and payload.get("type") in ("task_started", "task_complete", "task_aborted"):
            m.phase = "working"
        usage, last_usage = None, None
        if kind == "event_msg" and payload.get("type") == "token_count":
            info = payload.get("info") or {}
            if isinstance(info, dict):
                usage = info.get("total_token_usage")
                last_usage = info.get("last_token_usage")
        elif kind == "token_usage_record":
            usage = payload.get("thread_token_usage")
            last_usage = payload.get("usage")
        if isinstance(usage, dict) and number(usage.get("total_tokens")) is not None:
            m.tokens = int(usage["total_tokens"])
            m.tokens_partial = False
            fields = ("input_tokens", "cached_input_tokens", "cache_write_input_tokens", "output_tokens")
            totals = {k: number(usage.get(k, 0)) for k in fields}
            complete = all(v is not None for v in totals.values()) and all(k in usage for k in ("input_tokens", "output_tokens"))
            previous = cursor.codex_totals
            if not complete:
                cursor.estimate_incomplete = True
                m.estimate_note = "Input/output token breakdown not reported"
            elif totals != previous:
                if previous is not None and all(totals[k] >= previous[k] for k in fields):
                    delta = {k: totals[k] - previous[k] for k in fields}
                elif cursor.truncated or previous is not None:
                    delta = last_usage if isinstance(last_usage, dict) else {}
                    cursor.estimate_incomplete = True
                else:
                    delta = totals
                context_input = last_usage.get("input_tokens") if isinstance(last_usage, dict) else None
                cursor.estimates[("codex", len(cursor.estimates))] = price_estimate("codex", m.model, delta, context_input)
                cursor.codex_totals = totals
                update_estimate(cursor)

    elif provider == "claude":
        # Sidechain entries belong to subagents, not this pane's main session.
        if record.get("isSidechain"):
            return
        if kind == "assistant":
            if isinstance(message.get("model"), str):
                m.model = one_line(message["model"], 80)
            effort = record.get("perTurnEffort") or record.get("effort")
            if isinstance(effort, str):
                m.effort = one_line(effort, 24)
            usage = message.get("usage")
            message_id = message.get("id") or record.get("uuid")
            if isinstance(usage, dict) and message_id and not cursor.cumulative_tokens:
                # Streaming blocks repeat message ids. Replace each message's
                # usage; adding records would multiply its input/cache tokens.
                cursor.usages[message_id] = sum(number(usage.get(k)) or 0 for k in (
                    "input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens"))
                m.tokens = int(sum(cursor.usages.values()))
                m.tokens_partial = cursor.truncated
            if isinstance(usage, dict) and message_id:
                cursor.estimates[message_id] = price_estimate("claude", message.get("model", ""), usage)
                update_estimate(cursor)
            content = message.get("content")
            if isinstance(content, list):
                assistant_message(content)
            for block in content if isinstance(content, list) else []:
                if not isinstance(block, dict):
                    continue
                if block.get("type") in ("thinking", "redacted_thinking"):
                    m.phase = "thinking"
                elif block.get("type") == "text":
                    m.phase = "writing"
                elif block.get("type") == "tool_use":
                    call(block.get("name"), block.get("id"), tool_detail(block.get("input")))
        elif kind == "user":
            content = message.get("content")
            for block in content if isinstance(content, list) else []:
                if isinstance(block, dict) and block.get("type") == "tool_result" and cursor.call_id:
                    returned(block.get("tool_use_id"), block.get("is_error", False))
        elif kind == "cost-state":
            if number(record.get("totalCostUSD")) is not None:
                m.cost = float(record["totalCostUSD"])
                m.cost_partial = bool(record.get("hasUnknownModelCost"))
            start = timestamp(record.get("startTime"))
            if start:
                m.started_at = start
            models = record.get("modelUsage")
            if isinstance(models, dict) and models and all(isinstance(u, dict) for u in models.values()):
                m.tokens = int(sum(number(u.get(k)) or 0 for u in models.values()
                                   for k in ("inputTokens", "outputTokens", "cacheReadInputTokens", "cacheCreationInputTokens")))
                m.tokens_partial = False
                cursor.cumulative_tokens = True
                cursor.usages.clear()
        elif kind == "result" and number(record.get("total_cost_usd")) is not None:
            m.cost = float(record["total_cost_usd"])


class Telemetry:
    def __init__(self):
        self.cursors: dict[tuple, Cursor] = {}
        self.misses: dict[tuple, float] = {}
        self.observed: dict[tuple, tuple] = {}

    def find(self, agent: Agent) -> Path | None:
        provider = agent.provider or agent.kind
        directories = [p.resolve() for p in roots(provider)]
        if agent.session_kind == "path":
            candidate = Path(agent.session_ref).expanduser().resolve()
            # A server-supplied path may not turn this reader into an arbitrary
            # file reader. Only provider JSONL session stores are eligible.
            if candidate.suffix == ".jsonl" and any(candidate.is_relative_to(r) for r in directories):
                return candidate if candidate.is_file() else None
        elif agent.session_kind == "id" and SESSION_ID.fullmatch(agent.session_ref):
            for root in directories:
                pattern = "*/" + agent.session_ref + ".jsonl" if provider == "claude" else "**/*" + agent.session_ref + ".jsonl"
                for found in root.glob(pattern):
                    resolved = found.resolve()
                    if resolved.is_relative_to(root) and resolved.is_file():
                        return resolved
        return None

    def forget(self, agents: list[Agent]) -> None:
        live = {a.identity for a in agents}
        self.cursors = {k: v for k, v in self.cursors.items() if k in live}
        self.misses = {k: v for k, v in self.misses.items() if k in live}
        self.observed = {k: v for k, v in self.observed.items() if k in live}

    def read(self, agent: Agent) -> Metrics:
        key, now = agent.identity, time.time()
        state = self.observed.get(key)
        if state is None:
            state = (agent.status, agent.state_seq, now, now)
        elif (agent.status, agent.state_seq) != state[:2]:
            state = (agent.status, agent.state_seq, state[2], now)
        self.observed[key] = state
        cursor = self.cursors.get(key)
        issue = ""
        try:
            if cursor is None and now >= self.misses.get(key, 0):
                found = self.find(agent)
                if found:
                    cursor = self.cursors[key] = Cursor(found)
                else:
                    self.misses[key] = now + 15
            if cursor:
                self.update(cursor, agent.provider or agent.kind)
        except (OSError, ValueError) as error:
            issue = "Session metrics unavailable: " + one_line(str(error))
        m = replace(cursor.metrics) if cursor else Metrics()
        m.seen_at, m.status_since = state[2], state[3]
        m.source = (agent.provider or agent.kind) + " session log" if cursor else "Herdr status"
        m.issue = issue
        if m.cost is None and m.estimated_cost is None:
            m.cost_reason = (issue if issue else "Dollar total not reported by session" if cursor else
                             "Session reference not reported by Herdr" if not agent.session_ref else
                             "No matching local session log")
            if cursor and cursor.estimates:
                m.cost_reason = next((note for cost, note in cursor.estimates.values() if cost is None), m.cost_reason)
        return m

    @staticmethod
    def update(cursor: Cursor, provider: str) -> None:
        with cursor.path.open("rb") as stream:
            stat = os.fstat(stream.fileno())
            identity = (stat.st_dev, stat.st_ino)
            stream.seek(max(0, cursor.offset - 64))
            boundary = stream.read(min(cursor.offset, 64))
            if cursor.identity != identity or stat.st_size < cursor.offset or boundary != cursor.boundary:
                cursor.offset, cursor.identity, cursor.boundary = 0, identity, b""
                cursor.metrics, cursor.usages, cursor.call_id = Metrics(), {}, ""
                cursor.cumulative_tokens, cursor.truncated = False, False
                cursor.estimates, cursor.codex_totals, cursor.estimate_incomplete = {}, None, False
            start = max(cursor.offset, stat.st_size - MAX_READ)
            if cursor.offset == 0 and start:
                stream.seek(0)
                # Read timestamps/model/session metadata from a bounded header.
                for line in stream.read(32768).splitlines()[:32]:
                    try:
                        record = json.loads(line)
                        if isinstance(record, dict):
                            consume(cursor, record, provider)
                    except (ValueError, UnicodeError):
                        continue
                cursor.usages.clear()
                cursor.estimates.clear()
                cursor.codex_totals = None
                cursor.metrics.estimated_cost = None
                cursor.truncated = True
                if provider == "codex":
                    cursor.metrics.model = ""
            elif start > cursor.offset:
                cursor.truncated = True
                cursor.codex_totals = None
            stream.seek(start)
            data = stream.read(MAX_READ)
            end = data.rfind(b"\n")
            if end < 0:
                return
            lines = data[:end].split(b"\n")
            if start > cursor.offset:
                lines = lines[1:]
            for line in lines:
                try:
                    record = json.loads(line)
                    if isinstance(record, dict):
                        consume(cursor, record, provider)
                except (ValueError, UnicodeError, TypeError):
                    continue
            cursor.offset = start + end + 1
            stream.seek(max(0, cursor.offset - 64))
            cursor.boundary = stream.read(min(cursor.offset, 64))
            if cursor.estimates:
                update_estimate(cursor)


def screen_call(text: str) -> str:
    """Recognize tool-shaped lines only, without labeling arbitrary prose a call."""
    for line in reversed(clean(text).splitlines()):
        match = re.match(r"\s*[⏺●•]\s+([A-Z][\w.-]{1,32})\s*(?:\(|:)", line)
        if match:
            return match[1]
    return ""


def duration(seconds: float | None) -> str:
    if seconds is None:
        return "—"
    seconds = max(0, int(seconds))
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60:02}s"
    if seconds < 86400:
        return f"{seconds // 3600}h {seconds % 3600 // 60:02}m"
    return f"{seconds // 86400}d {seconds % 86400 // 3600}h"


def token_label(m: Metrics) -> str:
    if m.tokens is None:
        return "—"
    amount = f"{m.tokens / 1_000_000:.1f}m" if m.tokens >= 1_000_000 else f"{m.tokens / 1000:.1f}k" if m.tokens >= 1000 else str(m.tokens)
    return ("≥" if m.tokens_partial else "") + amount


def cost_label(m: Metrics) -> str:
    cost = cost_value(m)
    if cost is None:
        return "—"
    value = "$0.00" if cost == 0 else "<$0.01" if cost < .005 else f"${cost:.2f}"
    partial = m.cost_partial if m.cost is not None else m.estimate_partial
    return ("≥" if partial else "") + ("~" if m.cost is None else "") + value


def cost_value(m: Metrics) -> float | None:
    return m.cost if m.cost is not None else m.estimated_cost


def cost_detail(m: Metrics) -> str:
    if m.cost is not None:
        return "Reported session total; not an invoice"
    if m.estimated_cost is not None:
        return "Estimated API token cost · " + m.estimate_note
    return m.cost_reason or "Token usage or pricing unavailable"
