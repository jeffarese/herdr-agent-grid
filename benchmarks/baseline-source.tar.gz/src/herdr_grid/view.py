"""Compact agent cards with progressive disclosure and explicit data provenance."""
from __future__ import annotations

from dataclasses import dataclass
import math
import time
import textwrap

from .model import Agent, Layout, Rect, cell_width, clip, layout
from .refresh import State
from .telemetry import Metrics, cost_detail, cost_label, cost_value, duration, token_label
from .icons import logo_for, normalize
from .visuals import PHASES, core, model_effort, phase_for, tool_glyph
import os


@dataclass(frozen=True)
class Draw:
    x: int
    y: int
    text: str
    style: str = "normal"


STATUS = {"working": ("● WORKING", "Working"), "blocked": ("! NEEDS INPUT", "Needs input"),
          "done": ("✓ DONE", "Done"), "idle": ("○ IDLE", "Idle"),
          "unknown": ("? UNKNOWN", "Unknown")}


class View:
    def __init__(self, icons: str | None = None, motion: bool | None = None):
        self.selected = ""
        self.query = ""
        self.searching = False
        self.zoom = False
        self.message = ""
        self.items: list[Agent] = []
        self.visible: list[Agent] = []
        self.geometry = Layout((), 1, 1)
        self.page = 0
        self.page_count = 1
        self.top = 5
        self.icons = icons or os.environ.get("HERDR_GRID_ICONS", "auto")
        self.motion = motion if motion is not None else os.environ.get("HERDR_GRID_MOTION", "on") != "off"

    def arrange(self, state: State, width: int, height: int) -> None:
        query = self.query.casefold()
        self.items = [a for a in state.agents if query in
                      f"{a.name} {a.kind} {a.title} {a.workspace} {a.status} "
                      f"{state.metrics.get(a.pane_id, Metrics()).last_call}".casefold()]
        # Stable partition: active work comes first; keep Herdr's order within
        # each group and retain selection by pane ID across status changes.
        self.items.sort(key=lambda a: a.status != "working")
        if self.selected not in {a.pane_id for a in self.items}:
            self.selected = self.items[0].pane_id if self.items else ""
        self.top = 5 if height >= 18 else 2
        index = self.index
        self.geometry = layout(width, max(1, height - self.top - 2),
                               1 if self.zoom and self.items else len(self.items))
        self.page = index // self.geometry.capacity
        self.page_count = max(1, math.ceil(len(self.items) / self.geometry.capacity))
        if self.zoom:
            self.visible = self.items[index:index + 1]
        else:
            start = self.page * self.geometry.capacity
            self.visible = self.items[start:start + self.geometry.capacity]

    @property
    def index(self) -> int:
        return next((i for i, a in enumerate(self.items) if a.pane_id == self.selected), 0)

    @property
    def chosen(self) -> Agent | None:
        return self.items[self.index] if self.items else None

    def move(self, delta: int, wrap: bool = False) -> None:
        if self.items:
            index = self.index + delta
            index = index % len(self.items) if wrap else max(0, min(len(self.items) - 1, index))
            self.selected = self.items[index].pane_id

    def targets(self) -> dict[str, int]:
        # Visible terminal reads provide a last-call fallback for providers
        # without a matched transcript. No transcript text is drawn in cards.
        return {a.pane_id: 40 for a in self.visible}

    def hit(self, x: int, y: int) -> Agent | None:
        return next((a for a, rect in zip(self.visible, self.geometry.rects)
                     if rect.contains(x, y - self.top)), None)

    def draw(self, state: State, width: int, height: int, animation_time: float | None = None) -> list[Draw]:
        self.arrange(state, width, height)
        commands: list[Draw] = []
        now = time.time()
        animation_time = time.monotonic() if animation_time is None else animation_time

        def put(x: int, y: int, text: str, style: str = "normal", limit: int | None = None):
            if 0 <= y < height and 0 <= x < width:
                commands.append(Draw(x, y, clip(text, min(width - x, limit if limit is not None else width), True), style))

        heading = "  ◆ AGENT GRID"
        if self.query:
            heading += f"  /  {len(self.items)} of {len(state.agents)}"
        elif self.zoom:
            heading += "  /  agent details"
        elif self.page_count > 1:
            heading += f"  /  {self.page + 1} of {self.page_count}"
        put(0, 0, heading, "brand")
        connection = "OFFLINE" if state.error else "LIVE" if state.updated else "CONNECTING"
        stale = state.updated and time.monotonic() - state.updated > 5
        if stale and not state.error:
            connection = "SYNCING"
        if width >= 55:
            put(width - len(connection) - 3, 0, "● " + connection,
                "blocked" if state.error else "done" if state.updated else "muted")
        counts = {s: sum(a.status == s for a in state.agents) for s in STATUS}
        x = 2
        for status, label in (("working", "working"), ("blocked", "need input"),
                              ("done", "done"), ("idle", "idle"), ("unknown", "unknown")):
            if counts[status]:
                value = f"{counts[status]} {label}"
                put(x, 1, value, status)
                x += len(value) + 4
        if not state.agents:
            put(2, 1, "No active agents" if state.updated else "Waiting for Herdr…", "muted")
        if self.top == 5:
            reported = []
            seen = set()
            for a in state.agents:
                key = (a.provider or a.kind, a.session_kind, a.session_ref) if a.session_ref else a.identity
                if key in seen:
                    continue
                seen.add(key)
                reported.append(state.metrics.get(a.pane_id, Metrics()))
            costs = [m for m in reported if cost_value(m) is not None]
            estimated = any(m.cost is None for m in costs)
            tokens = [m for m in reported if m.tokens is not None]
            amount = sum(cost_value(m) for m in costs) if costs else None
            partial = any(m.cost_partial if m.cost is not None else m.estimate_partial for m in costs)
            aggregate = Metrics(cost=amount if not estimated else None,
                                cost_partial=partial,
                                estimated_cost=amount if estimated else None,
                                estimate_partial=partial,
                                tokens=sum(m.tokens for m in tokens) if tokens else None,
                                tokens_partial=any(m.tokens_partial for m in tokens))
            spaces = len({a.workspace for a in state.agents})
            summary = (f"{len(state.agents)} agents · {spaces} workspaces   "
                       f"API cost {cost_label(aggregate) if costs else 'unavailable'} ({len(costs)}/{len(reported)} {'covered' if estimated else 'reported'})   "
                       f"Tokens {token_label(aggregate)} ({len(tokens)}/{len(reported)} reported)")
            put(2, 2, summary, "muted")
            if state.error:
                put(2, 3, "Connection unavailable · " + state.error, "blocked")
            elif stale:
                put(2, 3, f"Last inventory {duration(time.monotonic() - state.updated)} ago", "muted")
            else:
                put(2, 3, "API token cost  ·  ~ estimated  ·  ≥ partial  ·  — unavailable", "muted")
        if width < 12 or height < 7:
            put(0, min(2, height - 1), "Enlarge terminal", "muted")
            return commands
        if not self.items:
            message = "No agents match this filter" if self.query else "Waiting for agents in this session"
            put(2, max(self.top + 1, height // 2), message, "muted")

        for agent, original in zip(self.visible, self.geometry.rects):
            rect = Rect(original.x, original.y + self.top, original.width, original.height)
            x, y, w, h = rect.x, rect.y, rect.width, rect.height
            if w < 4 or h < 4:
                continue
            selected = agent.pane_id == self.selected
            m = state.metrics.get(agent.pane_id, Metrics())
            phase = phase_for(agent.status, m)
            badge = PHASES[phase][0]
            status_style = agent.status if agent.status in STATUS else "unknown"
            border = "focus:" + status_style if selected else status_style if agent.status in ("working", "blocked", "done") else "border"
            settled = agent.status in ("done", "idle") and not selected
            put(x, y, "╭" + "─" * (w - 2) + "╮", border, w)
            put(x, y + h - 1, "╰" + "─" * (w - 2) + "╯", border, w)
            for line in range(1, h - 1):
                put(x, y + line, "│", border, 1)
                put(x + w - 1, y + line, "│", border, 1)
            number = self.items.index(agent) + 1
            put(x + 2, y, f" {'›' if selected else ' '} {number:02}  {agent.name} ",
                border if agent.status in ("working", "blocked", "done") else "selected" if selected else "title", w - 5)

            def inside(row: int, text: str, style: str = "normal"):
                if 0 < row < h - 1:
                    put(x + 2, y + row, text, style, w - 4)

            harness = normalize(agent.kind)
            put(x + 2, y + 1, logo_for(harness, self.icons), "harness:" + harness, 1)
            put(x + 4, y + 1, model_effort(m.model, m.effort), "title", w - 6)
            inside(2, agent.title, "settled" if settled else "title")
            age = duration(now - m.started_at) if m.started_at else "—"
            last_age = duration(now - m.call_at) if m.call_at else "—"
            qualifier = "seen" if m.call_source == "screen" else "ago"
            call = m.last_call or "Not available"
            if m.call_done is not None:
                call += "  ·  " + ("returned" if m.call_done else "called")
            if h >= 12:
                put(x + 2, y + 3, agent.workspace, "muted", max(1, w - len(badge) - 6))
                if w > len(badge) + 8:
                    put(x + w - len(badge) - 2, y + 3, badge, status_style, len(badge))
                core_rows = 2 if h >= 14 else 1
                core_top = 4
                for cx, cy, char, style in core(phase, w - 4, core_rows, animation_time,
                                              agent.pane_id, motion=self.motion):
                    put(x + 2 + cx, y + core_top + cy, char, style, 1)
                call_row = 6 if h >= 14 else 5
                # Keep the call and its age in separate columns.
                latest = "▸ " + call if m.last_call else "Latest call —"
                right = (f"seen {last_age}" if qualifier == "seen" else f"{last_age} ago") if m.call_at else ""
                call_width = w - 4 - len(right) - (2 if right else 0)
                put(x + 2, y + call_row, latest, "settled" if settled else "accent" if m.last_call else "muted", call_width)
                if w >= 40:
                    put(x + w - len(right) - 2, y + call_row, right, "muted", len(right))
                elif h < 14:
                    inside(6, f"Last call {last_age}" if m.call_at else "", "muted")
                inside(7, "» " + m.last_message if m.last_message else "Message unavailable", "settled" if settled else "normal")
                divider = 8
                labels_row, values_row = 9, 10
                put(x + 1, y + divider, "─" * (w - 2), "border", w - 2)
                column = (w - 4) // 3
                for offset, label, value in ((0, "SESSION", age), (column, "TOKENS", token_label(m)),
                                             (column * 2, "EST. COST" if m.cost is None and m.estimated_cost is not None else "API COST",
                                              cost_label(m) if cost_value(m) is not None else "Unavailable")):
                    put(x + 2 + offset, y + labels_row, label, "muted", column)
                    put(x + 2 + offset, y + values_row, value, "settled" if settled else "metric", column)
                if h >= 14:
                    inside(12, "TRAIL", "muted")
                    if m.trail:
                        for offset, entry in enumerate(m.trail[-max(1, (w - 12) // 2):]):
                            glyph, style = tool_glyph(entry.name)
                            put(x + 8 + offset * 2, y + 12, glyph,
                                "failed" if entry.error else style, 1)
                    else:
                        put(x + 8, y + 12, "—", "muted", 1)
                    if m.issue:
                        inside(h - 2, "! " + m.issue, "blocked")
            else:
                inside(3, f"Last  {call}", "accent" if m.last_call else "muted")
                call_label = "Seen" if m.call_source == "screen" else "Call"
                inside(4, f"Time  {age}  ·  {call_label} {last_age}", "muted")
                inside(5, f"API   {cost_label(m) if cost_value(m) is not None else 'Unavailable'}  ·  {token_label(m)} tokens", "metric")
                put(x + 2, y + 6, badge, status_style, len(badge))
                if w > len(badge) + 8:
                    compact_detail = agent.workspace if h >= 9 else "» " + m.last_message if m.last_message else "Message unavailable"
                    put(x + len(badge) + 4, y + 6, compact_detail, "muted", w - len(badge) - 6)
                inside(7, "» " + m.last_message if m.last_message else "Message unavailable", "muted")

            if self.zoom and h >= 23:
                inside(14, "DETAILS", "muted")
                observed = duration(now - m.status_since) if m.status_since else "—"
                inside(15, f"Status observed  ≥{observed}   ·   {agent.pane_id}")
                inside(16, f"Model / effort   {m.model or 'Not reported'}@{m.effort or '?'}")
                inside(17, f"Metrics source   {m.source or 'Herdr status'}")
                inside(18, "Latest call      " + ("Terminal observation" if m.call_source == "screen" else
                                                  "Session transcript" if m.call_source else "Not reported"))
                inside(19, "API cost         " + cost_detail(m), "muted")
                inside(20, "Token count      Includes input, output and cached input", "muted")
                if m.tokens_partial:
                    inside(21, "Token coverage   Partial transcript · shown as a lower bound", "muted")
                elif m.estimate_partial and m.cost is None:
                    inside(21, "Cost coverage    Partial usage/model history · shown as a lower bound", "muted")
                if h >= 27:
                    message_age = duration(now - m.message_at) + " ago" if m.message_at else ""
                    inside(22, "LATEST ASSISTANT MESSAGE  " + message_age, "muted")
                    lines = textwrap.wrap(m.last_message or "Message unavailable", width=max(1, w - 4))
                    available = min(6, h - 25)
                    for row, line in enumerate(lines[:available]):
                        inside(23 + row, line + ("…" if row == available - 1 and len(lines) > available else ""))

        if self.searching or self.query:
            put(0, height - 2, "  / " + self.query + ("▏" if self.searching else ""), "selected")
        elif self.message:
            put(0, height - 2, "  " + self.message, "blocked")
        elif self.chosen:
            a = self.chosen
            m = state.metrics.get(a.pane_id, Metrics())
            detail = m.issue or ("Activity read unavailable" if a.pane_id in state.errors else m.source or "Herdr status")
            put(0, height - 2, f"  {a.name} · {a.workspace}  /  {detail}", "muted")
        legend = "  ↑↓←→ select   Enter/click open   z details   / filter   r refresh   Esc close"
        if self.page_count > 1 and not self.zoom:
            legend = "  Arrows select  Enter/click open  PgUp/PgDn pages  z details  / filter  Esc close"
        if self.searching:
            legend = "  Type to filter   Enter finish   Esc clear filter"
        put(0, height - 1, legend, "muted")
        return commands


def plain_frame(commands: list[Draw], width: int, height: int) -> str:
    """Render commands without terminal controls, for fixtures and inspection."""
    rows = [[" "] * width for _ in range(height)]
    for command in commands:
        x = command.x
        for char in command.text:
            size = cell_width(char)
            if size == 0:
                if x > 0:
                    previous = x - 1
                    while previous > 0 and rows[command.y][previous] == "":
                        previous -= 1
                    rows[command.y][previous] += char
                continue
            if x + size > width:
                break
            rows[command.y][x] = char
            for continuation in range(1, size):
                rows[command.y][x + continuation] = ""
            x += size
    return "\n".join("".join(row) for row in rows)
